#!/bin/bash
depends mod_cecho
cecho "   __                     _        _               ___      _                         _ " magenta
cecho "  /__\_ _ _   _  ___  ___| |_ _ __(_) __ _ ___    / __\ ___| |_ _ __ __ _ _   _  __ _| |" magenta
cecho " /_\/ _\` | | | |/ _ \/ __| __| '__| |/ _\` / __|  /__\/// _ \ __| '__/ _\` | | | |/ _\` | |" magenta
cecho "//_| (_| | |_| |  __/\__ \ |_| |  | | (_| \__ \ / \/  \  __/ |_| | | (_| | |_| | (_| | |" magenta
cecho "\__/\__, |\__,_|\___||___/\__|_|  |_|\__,_|___/ \_____/\___|\__|_|  \__,_|\__, |\__,_|_|" magenta
cecho "       |_|                                                                |___/         " magenta
echo ""
echo ""
cecho "           A My Little Pony: Friendship is Magic, inspired RPG for most archs           " cyan