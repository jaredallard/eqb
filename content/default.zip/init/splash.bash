#!/bin/bash

# You can clear the screen here with:
# clear

depends mod_cecho
cecho "eqb default content pack screen" magenta
cecho "press ENTER or wait 5 seconds" cyan
