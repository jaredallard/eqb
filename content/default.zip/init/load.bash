#!/bin/bash
clear
level="$1"
cecho "Loading Level..." red
echo "OK"
clear

# Load Item API
source $ENGINE_DIR/rrpg_item.bash

# Build the UI.
draw_main && prompt $1
