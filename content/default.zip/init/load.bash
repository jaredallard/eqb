#!/bin/bash
clear
level="$1"
cecho "Loading Level..." red
echo "OK"
clear

# Build the UI.
draw_main && prompt $1
